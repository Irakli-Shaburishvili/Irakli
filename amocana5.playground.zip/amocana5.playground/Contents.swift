
func countVariants(stairsCount: Int) -> Int {
    var result: [Int] = [Int].init(repeating: 0, count: stairsCount + 1)
    result[0] = 1
    result[1] = 1
    result[2] = 2
    for i in 3...stairsCount {
        result[i] = result[i - 1] + result[i-2]
    }

    return result[stairsCount]
}



