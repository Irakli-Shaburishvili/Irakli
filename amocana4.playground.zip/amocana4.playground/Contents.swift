

func isProperty(sequence: String) -> Bool{
    var counter = 0
    for c in sequence {
        if c == "(" {
            counter += 1
        }else {
            counter -= 1
        }
        if counter < 0 {
            return false
        }
    }
    
    return counter == 0
}

