class collectionElement<K: Hashable, V> {
    var key: K
    var value: V?
    
    init(_ key: K, _ value: V?) {
        self.key = key
        self.value = value
    }
}

struct myCollection<Key: Hashable, Value> {
    
    typealias storage = [collectionElement<Key, Value>]
    
    private var elementsArray: [storage]
    
    init(capacity: Int) {
        assert(capacity > 0)
        elementsArray = Array<storage>(repeatElement([], count: capacity))
    }
    
    mutating func remove(for key: Key){
        let index = self.getIndex(for: key)
        for (i, e) in elementsArray[index].enumerated() {
            if e.key == key {
                elementsArray[index].remove(at: i)
            }
        }
    }
    
    mutating func add(data value: Value, forKey key: Key) {
        let loc = self.getIndex(for: key)
        let element = collectionElement(key, value)
        elementsArray[loc].append(element)
    }
    
    private func getIndex(for key: Key) -> Int {
        var divisor: Int = 0
        for key in String(describing: key).unicodeScalars {
            divisor += abs(Int(key.value.hashValue))
        }
        let index = abs(divisor) % elementsArray.count
        return index
    }
    
}
