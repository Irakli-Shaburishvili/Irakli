
func isPalindrome(text: String) -> Bool {
    for i in 0 ..< text.count / 2 {
        var headIndex: String.Index
        var tailIndex: String.Index

        headIndex = text.index(text.startIndex, offsetBy: i)
        tailIndex = text.index(text.startIndex, offsetBy: text.count - (i + 1))
   
        if text[headIndex] != text[tailIndex] {
            return false
        }
    }
    return true
}


