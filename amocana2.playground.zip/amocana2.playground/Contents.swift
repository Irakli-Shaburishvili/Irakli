

func minSplit(amount: Int) -> Int {
    var currentAmount = amount
    var result = 0
    while currentAmount > 0 {
        switch currentAmount {
        case _ where currentAmount >= 50:
            currentAmount -= 50
            result += 1
        case _ where currentAmount >= 20:
            currentAmount -= 20
            result += 1
        case _ where currentAmount >= 10:
            currentAmount -= 10
            result += 1
        case _ where currentAmount >= 5:
            currentAmount -= 5
            result += 1
        default :
            currentAmount -= 1
            result += 1
        }
    }
    return result
}

