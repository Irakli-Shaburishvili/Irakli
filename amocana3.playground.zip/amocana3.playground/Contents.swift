func notContains(Array: [Int]) -> Int {
    let arraySize = getMaxElement(array: Array)
    var newArray: [Int?] = [Int?](repeating: nil, count: arraySize + 1)

    for j in Array {
        if j <= 0 {
            continue
        }
        newArray[j] = j
    }

    for i in 1..<newArray.count {
        if newArray[i] == nil {
            return i
        }
    }
    return newArray.count
}

func getMaxElement(array: [Int]) -> Int {
    var result = 0
    for i in 0..<array.count {
        if result < array[i] {
            result = array[i]
        }
    }
    return result
}


